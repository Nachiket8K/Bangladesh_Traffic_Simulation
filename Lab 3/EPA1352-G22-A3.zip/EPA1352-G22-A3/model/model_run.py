from model import BangladeshModel, compute_average_driving, compute_worst_bridge, compute_worst_bridge_delay

"""
    Run simulation
    Print output at terminal
"""

# ---------------------------------------------------------------

# run time 5 x 24 hours; 1 tick 1 minute
run_length = 5 * 24 * 60

# run time 1000 ticks
# run_length = 1000

seed = 1234567

sim_model = BangladeshModel(seed=seed, prob_A=0, prob_B=0, prob_C=0, prob_D=0)

"""
# draw network
import networkx as nx
G = sim_model.network
pos = nx.get_node_attributes(G,'pos')
nx.draw(G, pos = pos, with_labels = False, node_size = 5)
"""

# Check if the seed is set
print("SEED " + str(sim_model._seed))

# One run with given steps
for i in range(run_length):
    sim_model.step()

# print metrics to console after model run
print(compute_average_driving(sim_model))

print(compute_worst_bridge(sim_model))

print(compute_worst_bridge_delay(sim_model))
